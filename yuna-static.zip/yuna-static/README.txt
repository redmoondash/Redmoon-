yuna - link page (static)

1) حط صورتك في نفس الفولدر باسم avatar.jpg
2) في index.html غيّر YOUR-DOMAIN في og:image لدومينك (عشان معاينة الرابط)
3) ارفع الفولدر كله على أي استضافة: Netlify Drop / Cloudflare Pages / GitHub Pages / Vercel
